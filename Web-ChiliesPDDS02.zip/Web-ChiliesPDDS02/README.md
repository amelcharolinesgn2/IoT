# Chili Leaf Plant Disease Detection System (CLPDDS)


Download Pre Trained model from https://github.com/amelcharolinesgn2/IoT/Web-ChiliesPDDS01/datasets/plantmodel/1

This code is designed to be deployed on floyd hub and make an REST end point api that takes an image  as input detects the related chilli disease , wirite its fingdings to firebase and then return the same via the same REST api


you can connect it to your firebase entering authentication information in app.py file




