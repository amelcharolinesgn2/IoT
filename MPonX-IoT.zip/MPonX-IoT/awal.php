<div class="main-content" style="background-image:url('images/Picture4.jpg');background-repeat: no-repeat;
  background-position: center;"> 
<div class="section__content section__content--p30">
                    <div class="container-fluid">
						<div class="row">
                            <div class="col-md-12">
                                <div>
								<p><h2>MPonXIoT</h2><h3>Monitoring Hidroponik-IoT</h3><p>
                                </div>
                            </div>
						</div>
					</div>
				</div>
			</div>