wlan_ssid = 'YOUR_WLAN_SSID'
wlan_pw = 'YOUR_WLAN_PASSWORD'

adafruit_user = 'YOUR_ADAFRUIT_USERNAME'
adafruit_key = 'YOUR_ADAFRUIT_KEY'
